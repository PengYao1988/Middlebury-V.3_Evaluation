// evaldisp.cpp 

// evaluate disparity map
// simple version for SDK
// supports upsampling of disp map if GT has higher resolution

// DS 7/2/2014
// 10/14/2014 changed computation of average error
// 1/27/2015 added clipping of valid (non-INF) disparities to [0 .. maxdisp]
//    in fairness to those methods that do not utilize the given disparity range
//    (maxdisp is specified at disp resolution, NOT GT resolution)

static const char *usage = "\n  usage: %s disp.pfm gtdisp.pfm badthresh maxdisp rounddisp [mask.png]\n\
    (or call with single argument badthresh to print column headers)\n";

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <vector>
#include "imageLib.h"
#include "png.h"

int verbose = 0;

////////////////////////////////////////////////////////////////////////////////////////////////////ImageIOpng.cpp///////

extern "C"{
#include "png.h"
}

#include "Image.h"
#include "Error.h"
#include <vector>

// global variables pointing to the png stuctures
static png_structp png_ptr = NULL;
static png_infop info_ptr = NULL;

static void pngfile_error(png_structp /*png_ptr*/, png_const_charp msg)
{
	throw CError(msg);
}

#define DEBUG_ImageIOpng 0

// TODO: the following function should go somewhere else, perhaps in ImageIO.cpp
// Make sure the image has the smallest number of bands before writing.
// That is, if it's 4 bands with full alpha, reduce to 3 bands.  
// If it's 3 bands with constant colors, make it 1-band.
CByteImage removeRedundantBands(CByteImage img)
{
    CShape sh = img.Shape();
	int w = sh.width, h = sh.height, nB = sh.nBands;
	int x, y;
	if (nB < 3)
		return img;

	// check if full alpha if alpha channel present
	bool fullAlpha = true;
	if (nB == 4) {
		for (y = 0; y < h && fullAlpha; y++) {
			uchar *pix = &img.Pixel(0, y, 0);
			for (x = 0; x < w; x++) {
				if (pix[3] != 255) {
					fullAlpha = false;
					break;
				}
				pix += nB;
			}
		}
	}
	if (!fullAlpha)
		return img;

	// check for equal colors
	bool equalColors = true;
	for (y = 0; y < h && equalColors; y++) {
		uchar *pix = &img.Pixel(0, y, 0);
		for (x = 0; x < w; x++) {
			if (pix[0] != pix[1] ||
				pix[0] != pix[2] ||
				pix[1] != pix[2]) {
					equalColors = false;
					break;
				}
				pix += nB;
		}
	}
	// at this point, if nB == 4 we can reduce to at least 3 bands,
	// and if equalColors we can reduce to 1 band.
	if (! equalColors && nB < 4)
		return img;

	int newNB = equalColors ? 1 : 3;

	if (DEBUG_ImageIOpng)
		fprintf(stderr, "reducing from %d to %d bands\n", nB, newNB);

	CShape sh2(w, h, newNB);
	CByteImage img2(sh2);
	
	for (y = 0; y < h; y++) {
		uchar *pix = &img.Pixel(0, y, 0);
		uchar *pix2 = &img2.Pixel(0, y, 0);
		for (x = 0; x < w; x++) {
			for (int b = 0; b < newNB; b++) {
				pix2[b] = pix[b];
			}
			pix += nB;
			pix2 += newNB;
		}
	}

	return img2;
}


void ReadFilePNG(CByteImage& img, const char* filename)
{
    // open the PNG input file
    FILE *stream = fopen(filename, "rb");
    if (stream == 0)
        throw CError("ReadFilePNG: could not open %s", filename);

    // first check the eight byte PNG signature
    png_byte pbSig[8];
    fread(pbSig, 1, 8, stream);
	if (!png_check_sig(pbSig, 8)) {
        fclose(stream);
        throw CError("ReadFilePNG: invalid PNG signature");
	}

    // create the two png(-info) structures
    png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL,
      (png_error_ptr)pngfile_error, (png_error_ptr)NULL);

	if (!png_ptr) {
        fclose(stream);
		throw CError("ReadFilePNG: error creating png structure");
	}

	info_ptr = png_create_info_struct(png_ptr);
	if (!info_ptr)
	{
		png_destroy_read_struct(&png_ptr, NULL, NULL);
        fclose(stream);
		throw CError("ReadFilePNG: error creating png structure");
	}

	png_init_io(png_ptr, stream);
	png_set_sig_bytes(png_ptr, 8);

	// read all PNG info up to image data
	png_read_info(png_ptr, info_ptr);

	// get width, height, bit-depth and color-type
	int width, height, bits, colorType, nBands;

	png_uint_32 pwidth, pheight;

	png_get_IHDR(png_ptr, info_ptr, 
		     &pwidth, &pheight,
		     //(png_uint_32 *)&width, (png_uint_32 *)&height,
		     &bits, &colorType, NULL, NULL, NULL);

	width = pwidth;
	height = pheight;

	nBands = (int)png_get_channels(png_ptr, info_ptr);

	if (DEBUG_ImageIOpng)
	fprintf(stderr, " w=%d, h=%d, %2d bits, %s, nB=%d",
		width, height, bits, 
		colorType == PNG_COLOR_TYPE_GRAY ? "gray" :
		colorType == PNG_COLOR_TYPE_PALETTE ? "plt " :
		colorType == PNG_COLOR_TYPE_RGB ? "rgb " :
		colorType == PNG_COLOR_TYPE_RGB_ALPHA ? "rgba" :
		colorType == PNG_COLOR_TYPE_GRAY_ALPHA ? "gr-a" : "??? ",
		nBands);


	// get rid of lower-order byte in 16-bit images
	// TODO: could allow this and read in IntImage in this case...
	if (bits == 16)
		png_set_strip_16(png_ptr);

	// change palette color into RGB
	if (colorType == PNG_COLOR_TYPE_PALETTE)
		png_set_expand(png_ptr);

	// want at least 8 bits
	if (bits < 8)
		png_set_expand(png_ptr);

	// if there is a transparent palette entry, create alpha channel
	if (png_get_valid(png_ptr, info_ptr, PNG_INFO_tRNS))
		png_set_expand(png_ptr);

	// make gray images with alpha channel into RGBA -- TODO: or just ignore alpha?
	if (colorType == PNG_COLOR_TYPE_GRAY_ALPHA)
		// colorType == PNG_COLOR_TYPE_GRAY       // but leave gray images alone
		png_set_gray_to_rgb(png_ptr);

	// set the background color to draw transparent and alpha images over.
	// only needed for gray images with alpha 
	if (colorType == PNG_COLOR_TYPE_GRAY_ALPHA ||
		colorType == PNG_COLOR_TYPE_GRAY) {
		png_color_16 *pBackground;
		if (png_get_bKGD(png_ptr, info_ptr, &pBackground))
			png_set_background(png_ptr, pBackground, PNG_BACKGROUND_GAMMA_FILE, 1, 1.0);
		}

	// if required set gamma conversion
	// this seems to cause problems, so let's just leave gamma alone.
	//double gamma;
	//if (png_get_gAMA(png_ptr, info_ptr, &gamma)) {
	// //fprintf(stderr, "\n reading gamma %lf\n", gamma);
	//png_set_gamma(png_ptr, 1.0, gamma);
	//}

	// we need colors in BGR order, not RGB
	png_set_bgr(png_ptr);

	// always convert 3-band to 4-band images (add alpha):
	if (colorType == PNG_COLOR_TYPE_RGB)
		png_set_add_alpha(png_ptr, 255, PNG_FILLER_AFTER);

	// after the transformations have been registered update info_ptr data
	png_read_update_info(png_ptr, info_ptr);

	// get again width, height and the new bit-depth and color-type

	png_get_IHDR(png_ptr, info_ptr, 
		     &pwidth, &pheight,
		     //(png_uint_32 *)&width, (png_uint_32 *)&height,
		     &bits, &colorType, NULL, NULL, NULL);
	
	width = pwidth;
	height = pheight;

	nBands = (int)png_get_channels(png_ptr, info_ptr);

	if (DEBUG_ImageIOpng)
	fprintf(stderr, "  -> w=%d, h=%d, %2d bits, %s, nB=%d\n",
		width, height, bits,
		colorType == PNG_COLOR_TYPE_GRAY ? "gray" :
		colorType == PNG_COLOR_TYPE_PALETTE ? "plt " :
		colorType == PNG_COLOR_TYPE_RGB ? "rgb " :
		colorType == PNG_COLOR_TYPE_RGB_ALPHA ? "rgba" :
		colorType == PNG_COLOR_TYPE_GRAY_ALPHA ? "gr-a" : "??? ",
		nBands);
	

	if (! (nBands==1 || nBands==3 || nBands==4)) {
        fclose(stream);
		throw CError("ReadFilePNG: Can't handle nBands=%d", nBands);
	}

	// Set the image shape
	CShape sh(width, height, nBands);

	// Allocate the image if necessary
	img.ReAllocate(sh);

	//  allocate a vector of row pointers
	std::vector<uchar *> rowPtrs;
	rowPtrs.resize(height);
	for (int y = 0; y<height; y++)
		rowPtrs[y] = &img.Pixel(0, y, 0);

	// read the whole image
	png_read_image(png_ptr, &rowPtrs[0]);

 	// read the additional chunks in the PNG file (not really needed)
	png_read_end(png_ptr, NULL);

	png_destroy_read_struct(&png_ptr, &info_ptr, NULL);

	fclose(stream);
}


void WriteFilePNG(CByteImage img, const char* filename)
{
	img = removeRedundantBands(img);

    CShape sh = img.Shape();
    int width = sh.width, height = sh.height, nBands = sh.nBands;

	// Make sure the image has the smallest number of bands before writing.
	// That is, if it's 4 bands with full alpha, reduce to 3 bands.  
	// If it's 3 bands with constant colors, make it 1-band.

    FILE *stream = fopen(filename, "wb");
    if (stream == 0)
        throw CError("WriteFilePNG: could not open %s", filename);

    png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL,
      (png_error_ptr)pngfile_error, (png_error_ptr)NULL);

	if (!png_ptr) {
        fclose(stream);
		throw CError("WriteFilePNG: error creating png structure");
	}

    info_ptr = png_create_info_struct(png_ptr);
    if (!info_ptr) {
        fclose(stream);
		throw CError("WriteFilePNG: error creating png structure");
    }

	png_init_io(png_ptr, stream);

	int bits = 8;
	int colortype =
		nBands == 1 ? PNG_COLOR_TYPE_GRAY :
		nBands == 3 ? PNG_COLOR_TYPE_RGB :
	                  PNG_COLOR_TYPE_RGB_ALPHA;
	png_set_IHDR(png_ptr, info_ptr, width, height, 
		bits, colortype,
		PNG_INTERLACE_NONE, 
		PNG_COMPRESSION_TYPE_DEFAULT, 
		PNG_FILTER_TYPE_DEFAULT);

	// write the file header information
	png_write_info(png_ptr, info_ptr);

	// swap the BGR pixels in the DiData structure to RGB
	png_set_bgr(png_ptr);

	//  allocate a vector of row pointers
	std::vector<uchar *> rowPtrs;
	rowPtrs.resize(height);
	for (int y = 0; y<height; y++)
		rowPtrs[y] = &img.Pixel(0, y, 0);

	// write the whole image
	png_write_image(png_ptr, &rowPtrs[0]);

	// write the additional chunks to the PNG file (not really needed)
	png_write_end(png_ptr, info_ptr);

	png_destroy_write_struct(&png_ptr, (png_infopp) NULL);

    fclose (stream);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////ImageIO.cpp
// Comment out next line if you don't have the PNG library
#define HAVE_PNG_LIB

#ifdef HAVE_PNG_LIB
// implemented in ImageIOpng.cpp
void ReadFilePNG(CByteImage& img, const char* filename);
void WriteFilePNG(CByteImage img, const char* filename);
#endif

// Comment out next line if not using jpeg library
//#define HAVE_JPEG_READER

#ifdef HAVE_JPEG_READER
// implemented in ReadJpg.cpp
void ReadFileJPG(CByteImage& img, const char* filename);
#endif

//
//  Truevision Targa (TGA):  support 24 bit RGB and 32-bit RGBA files
//

typedef unsigned char uchar;

struct CTargaHead
{
    uchar idLength;     // number of chars in identification field
    uchar colorMapType;	// color map type
    uchar imageType;	// image type code
    uchar cMapOrigin[2];// color map origin
    uchar cMapLength[2];// color map length
    uchar cMapBits;     // color map entry size
    short x0;			// x-origin of image
    short y0;			// y-origin of image
    short width;		// width of image
    short height;		// height of image
    uchar pixelSize;    // image pixel size
    uchar descriptor;   // image descriptor byte
};

// Image data type codes
const int TargaRawColormap	= 1;
const int TargaRawRGB		= 2;
const int TargaRawBW		= 3;
const int TargaRunColormap	= 9;
const int TargaRunRGB		= 10;
const int TargaRunBW		= 11;

// Descriptor fields
const int TargaAttrBits     = 15;
const int TargaScreenOrigin = (1<<5);
const int TargaCMapSize		= 256;
const int TargaCMapBands    = 3;
/*
const int TargaInterleaveShift = 6;
const int TargaNON_INTERLEAVE	0
const int TargaTWO_INTERLEAVE	1
const int TargaFOUR_INTERLEAVE	2
const int PERMUTE_BANDS		1
*/

class CTargaRLC
{
    // Helper class to decode run-length-coded image data
public:
    CTargaRLC(bool RLC) : m_count(0), m_RLC(RLC) {}
    uchar* getBytes(int nBytes, FILE *stream);
private:
    int m_count;        // remaining count in current run
    bool m_RLC;         // is stream run-length coded?
    bool m_isRun;       // is current stream of pixels a run?
    uchar m_buffer[4];  // internal buffer
};

inline uchar* CTargaRLC::getBytes(int nBytes, FILE *stream)
{
    // Get one pixel, which consists of nBytes
    if (nBytes > 4)
        throw CError("ReadFileTGA: only support pixels up to 4 bytes long");

    if (! m_RLC)
    {
    	if ((int)fread(m_buffer, sizeof(uchar), nBytes, stream) != nBytes)
    	    throw CError("ReadFileTGA: file is too short");
    }
    else
    {
        if (m_count == 0)
        {
            // Read in the next run count
            m_count = fgetc(stream);
            m_isRun = (m_count & 0x80) != 0;
            m_count = (m_count & 0x7f)  + 1;
            if (m_isRun)  // read the pixels for this run
    	        if ((int)fread(m_buffer, sizeof(uchar), nBytes, stream) != nBytes)
    	            throw CError("ReadFileTGA: file is too short");
        }
        if (! m_isRun)
        {
    	    if ((int)fread(m_buffer, sizeof(uchar), nBytes, stream) != nBytes)
    	        throw CError("ReadFileTGA: file is too short");
        }
        m_count -= 1;
    }
    return m_buffer;
}

void ReadFileTGA(CByteImage& img, const char* filename)
{
    // Open the file and read the header
    FILE *stream = fopen(filename, "rb");
    if (stream == 0)
        throw CError("ReadFileTGA: could not open %s", filename);
    CTargaHead h;
    if ((int)fread(&h, sizeof(CTargaHead), 1, stream) != 1)
	    throw CError("ReadFileTGA(%s): file is too short", filename);

    // Throw away the image descriptor
    if (h.idLength > 0)
    {
        char* tmp = new char[h.idLength];
        int nread = (int)fread(tmp, sizeof(uchar), h.idLength, stream);
        delete tmp;   // throw away this data
        if (nread != h.idLength)
	        throw CError("ReadFileTGA(%s): file is too short", filename);
    }
    //bool isRun = (h.imageType & 8) != 0;
    bool reverseRows = (h.descriptor & TargaScreenOrigin) != 0;
    int fileBytes = (h.pixelSize + 7) / 8;

    // Read the colormap
    uchar colormap[TargaCMapSize][TargaCMapBands];
    int cMapSize = 0;
    bool grayRamp = false;
    if (h.colorMapType == 1)
    {
        cMapSize = (h.cMapLength[1] << 8) + h.cMapLength[0];
        if (h.cMapBits != 24)
            throw CError("ReadFileTGA(%s): only 24-bit colormap currently supported", filename);
	    int l = fileBytes * cMapSize;
        if (l > TargaCMapSize * TargaCMapBands)
	        throw CError("ReadFileTGA(%s): colormap is too large", filename);
	    if ((int)fread(colormap, sizeof(uchar), l, stream) != l)
	        throw CError("ReadFileTGA(%s): could not read the colormap", filename);

        // Check if it's just a standard gray ramp
	int i;
        for (i = 0; i < cMapSize; i++) {
            for (int j = 0; j < TargaCMapBands; j++)
                if (colormap[i][j] != i)
                    break;
        }
        grayRamp = (i == cMapSize);    // didn't break out too soon
    }
    bool isGray = 
        h.imageType == TargaRawBW || h.imageType == TargaRunBW ||
        (grayRamp &&
	 (h.imageType == TargaRawColormap || h.imageType == TargaRunColormap));
    bool isRaw = h.imageType == TargaRawBW || h.imageType == TargaRawRGB ||
        (h.imageType == TargaRawRGB && isGray);

    // Determine the image shape
    CShape sh(h.width, h.height, (isGray) ? 1 : 4);
    
    // Allocate the image if necessary
    img.ReAllocate(sh, false);

    // Construct a run-length code reader
    CTargaRLC rlc(! isRaw);

    // Read in the rows
    for (int y = 0; y < sh.height; y++)
    {
        int yr = reverseRows ? sh.height-1-y : y;
        uchar* ptr = (uchar *) img.PixelAddress(0, yr, 0);
        if (fileBytes == sh.nBands && isRaw)
        {
            // Special case for raw image, same as destination
            int n = sh.width*sh.nBands;
    	    if ((int)fread(ptr, sizeof(uchar), n, stream) != n)
    	        throw CError("ReadFileTGA(%s): file is too short", filename);
        }
        else
        {
            // Read one pixel at a time
            for (int x = 0; x < sh.width; x++, ptr += sh.nBands)
            {
                uchar* buf = rlc.getBytes(fileBytes, stream);
                if (fileBytes == 1 && sh.nBands == 1)
                {
                    ptr[0] = buf[0];
                }
                else if (fileBytes == 1 && sh.nBands == 4)
                {
                    for (int i = 0; i < 3; i++)
                        ptr[i] = (isGray) ? buf[0] : colormap[buf[0]][i];
                    ptr[3] = 255;   // full alpha;
                }
                else if ((fileBytes == 3 || fileBytes == 4) && sh.nBands == 4)
                {
                    int i;
                    for (i = 0; i < fileBytes; i++)
                        ptr[i] = buf[i];
                    if (i == 3) // missing alpha channel
                        ptr[3] = 255;   // full alpha;
                }
                else
            	    throw CError("ReadFileTGA(%s): unhandled pixel depth or # of bands", filename);
            }
        }
    }

    if (fclose(stream))
        throw CError("ReadFileTGA(%s): error closing file", filename);
}

void WriteFileTGA(CImage img, const char* filename)
{
    // Only 1, 3, or 4 bands supported
    CShape sh = img.Shape();
    int nBands = sh.nBands;
    if (nBands != 1 && nBands != 3 && nBands != 4)
        throw CError("WriteFileTGA(%s): can only write 1, 3, or 4 bands", filename);

    // Only unsigned_8 supported directly
#if 0   // broken for now
    if (img.PixType() != unsigned_8)
    {
        CImage u8img(sh, unsigned_8);
        TypeConvert(img, u8img);
        img = u8img;
    }
#endif

    // Fill in the header structure
    CTargaHead h;
    memset(&h, 0, sizeof(h));
    h.imageType = (nBands == 1) ? TargaRawBW : TargaRawRGB;
        // TODO:  is TargaRawBW the right thing, or only binary?
    h.width     = sh.width;
    h.height    = sh.height;
    h.pixelSize = 8 * nBands;
    bool reverseRows = false;   // TODO: when is this true?

    // Open the file and write the header
    FILE *stream = fopen(filename, "wb");
    if (stream == 0)
        throw CError("WriteFileTGA: could not open %s", filename);
    if (fwrite(&h, sizeof(CTargaHead), 1, stream) != 1)
	    throw CError("WriteFileTGA(%s): file is too short", filename);

    // Write out the rows
    for (int y = 0; y < sh.height; y++)
    {
        int yr = reverseRows ? sh.height-1-y : y;
        char* ptr = (char *) img.PixelAddress(0, yr, 0);
        int n = sh.width*sh.nBands;
    	if ((int)fwrite(ptr, sizeof(uchar), n, stream) != n)
    	    throw CError("WriteFileTGA(%s): file is too short", filename);
    }

    if (fclose(stream))
        throw CError("WriteFileTGA(%s): error closing file", filename);
}

//
// Portable Graymaps: support PGM, PPM, and PMF images
//

void skip_comment(FILE *fp)
{
    // skip comment lines in the headers of pnm files

    char c;
    while ((c=getc(fp)) == '#')
        while (getc(fp) != '\n') ;
    ungetc(c, fp);
}

void skip_space(FILE *fp)
{
    // skip white space in the headers or pnm files

    char c;
    do {
        c = getc(fp);
    } while (c == '\n' || c == ' ' || c == '\t' || c == '\r');
    ungetc(c, fp);
}

void read_header(FILE *fp, const char *imtype, char c1, char c2, 
                 int *width, int *height, int *nbands, int thirdArg)
{
    // read the header of a pnmfile and initialize width and height

    char c;
  
	if (getc(fp) != c1 || getc(fp) != c2)
		throw CError("ReadFilePGM: wrong magic code for %s file", imtype);
	skip_space(fp);
	skip_comment(fp);
	skip_space(fp);
	fscanf(fp, "%d", width);
	skip_space(fp);
	fscanf(fp, "%d", height);
	if (thirdArg) {
		skip_space(fp);
		fscanf(fp, "%d", nbands);
	}
    // skip SINGLE newline character after reading image height (or third arg)
	c = getc(fp);
    if (c == '\r')      // <cr> in some files before newline
        c = getc(fp);
    if (c != '\n') {
        if (c == ' ' || c == '\t' || c == '\r')
            throw CError("newline expected in file after image height");
        else
            throw CError("whitespace expected in file after image height");
  }
}


void ReadFilePGM(CByteImage& img, const char* filename)
{
    // Open the file and read the header
    FILE *stream = fopen(filename, "rb");
    if (stream == 0)
        throw CError("ReadFilePGM: could not open %s", filename);

	int width, height, nBands;
	const char *dot = strrchr(filename, '.');
	int isGray = 0, isFloat = 0;

    if (strcmp(dot, ".pgm") == 0) {
		read_header(stream, "PGM", 'P', '5', &width, &height, &nBands, 1);
		isGray = 1;
	}
    else if (strcmp(dot, ".ppm") == 0) {
		read_header(stream, "PGM", 'P', '6', &width, &height, &nBands, 1);
		isGray = 0;
	}
    else if (strcmp(dot, ".pmf") == 0) {
		read_header(stream, "PMF", 'P', '9', &width, &height, &nBands, 1);
		isGray = 0;
        isFloat = 1;
	}


    // Determine the image shape
    CShape sh(width, height, (isGray) ? 1 : (isFloat) ? nBands : 4);
    
    // Allocate the image if necessary
    if (isFloat)
        ((CFloatImage *) &img)->ReAllocate(sh);
    else
        img.ReAllocate(sh);
 
    if (isGray || isFloat) { // read PGM or PMF
		
		// read the rows
        int n = isFloat ? width * nBands * sizeof(float) : sh.width;
		for (int y = 0; y<sh.height; y++) {
			uchar* ptr = (uchar *) img.PixelAddress(0, y, 0);
    	    if ((int)fread(ptr, sizeof(uchar), n, stream) != n)
    	        throw CError("ReadFilePGM(%s): file is too short", filename);
		}
	}
    else { // read PPM

		// read the rows
        int n = sh.width*3;
		std::vector<uchar> rowBuf;
		rowBuf.resize(n);
		for (int y = 0; y<sh.height; y++) {
	   	    if ((int)fread(&rowBuf[0], sizeof(uchar), n, stream) != n)
    	        throw CError("ReadFilePGM(%s): file is too short", filename);

			uchar* ptr = (uchar *) img.PixelAddress(0, y, 0);
			int x = 0;
			while (x < n) {
				ptr[2] = rowBuf[x++];
				ptr[1] = rowBuf[x++];
				ptr[0] = rowBuf[x++];
				ptr[3] = 255; // full alpha
				ptr += 4;
			}
		}
	}

    if (fclose(stream))
        throw CError("ReadFilePGM(%s): error closing file", filename);
}


// check whether machine is little endian
int littleendian()
{
    int intval = 1;
    uchar *uval = (uchar *)&intval;
    return uval[0] == 1;
}


// 1-band PFM image, see http://netpbm.sourceforge.net/doc/pfm.html
// 3-band not yet supported
void ReadFilePFM(CFloatImage& img, const char* filename)
{
    // Open the file and read the header
    FILE *fp = fopen(filename, "rb");
    if (fp == 0)
        throw CError("ReadFilePFM: could not open %s", filename);

    int width, height, nBands;
    read_header(fp, "PFM", 'P', 'f', &width, &height, &nBands, 0);

    skip_space(fp);

    float scalef;
    fscanf(fp, "%f", &scalef);  // scale factor (if negative, little endian)

    // skip SINGLE newline character after reading third arg
    char c = getc(fp);
    if (c == '\r')      // <cr> in some files before newline
        c = getc(fp);
    if (c != '\n') {
        if (c == ' ' || c == '\t' || c == '\r')
            throw CError("newline expected in file after scale factor");
        else
            throw CError("whitespace expected in file after scale factor");
    }

    // Set the image shape
    CShape sh(width, height, 1);
    
    // Allocate the image if necessary
    img.ReAllocate(sh);

    int littleEndianFile = (scalef < 0);
    int littleEndianMachine = littleendian();
    int needSwap = (littleEndianFile != littleEndianMachine);
    //printf("endian file = %d, endian machine = %d, need swap = %d\n", 
    //       littleEndianFile, littleEndianMachine, needSwap);

    for (int y = height-1; y >= 0; y--) { // PFM stores rows top-to-bottom!!!!
	int n = width;
	float* ptr = (float *) img.PixelAddress(0, y, 0);
	if ((int)fread(ptr, sizeof(float), n, fp) != n)
	    throw CError("ReadFilePFM(%s): file is too short", filename);
	
	if (needSwap) { // if endianness doesn't agree, swap bytes
	    uchar* ptr = (uchar *) img.PixelAddress(0, y, 0);
	    int x = 0;
	    uchar tmp = 0;
	    while (x < n) {
		tmp = ptr[0]; ptr[0] = ptr[3]; ptr[3] = tmp;
		tmp = ptr[1]; ptr[1] = ptr[2]; ptr[2] = tmp;
		ptr += 4;
		x++;
	    }
	}
    }
    if (fclose(fp))
        throw CError("ReadFilePGM(%s): error closing file", filename);
    }


// new 12/2/2013 DS: if filename == '-', write to stdout
void WriteFilePGM(CByteImage img, const char* filename)
{
    // Write a PGM, PPM, or PMF file
    CShape sh = img.Shape();
    int nBands = sh.nBands;
    int isFloat = img.PixType() == typeid(float);
    FILE *stream = NULL;

    if (strcmp(filename, "-") == 0) {
	stream = stdout;
    } else {
	// Determine the file extension
	const char *dot = strrchr(filename, '.');
	if (strcmp(dot, ".pgm") == 0 && nBands != 1)
	    throw CError("WriteFilePGM(%s): can only write 1-band image as pgm", filename);
	
	if (strcmp(dot, ".ppm") == 0 && nBands != 3 && nBands != 4)
	    throw CError("WriteFilePGM(%s): can only write 3 or 4-band image as ppm", filename);
	
	if (strcmp(dot, ".pmf") == 0 && ! isFloat)
	    throw CError("WriteFilePMF(%s): can only write floating point image as pmf", filename);
	
	// Open the file
	stream = fopen(filename, "wb");
	if (stream == 0)
	    throw CError("WriteFilePGM: could not open %s", filename);
    }

    if (nBands == 1 || isFloat) { // write PGM or PMF
		
		// write the header
        fprintf(stream, "P%d\n%d %d\n%d\n", isFloat ? 9 : 5, sh.width, sh.height,
                isFloat ? sh.nBands : 255);

		// write the rows
        int n = isFloat ? sh.width * sh.nBands * sizeof(float) : sh.width;
		for (int y = 0; y<sh.height; y++) {
			char* ptr = (char *) img.PixelAddress(0, y, 0);
    		if ((int)fwrite(ptr, sizeof(uchar), n, stream) != n)
    			throw CError("WriteFilePGM(%s): file is too short", filename);
		}
	}
    /*
    else if (nBands == 3) { // write PPM
		
		// write the header
		fprintf(stream, "P6\n%d %d\n%d\n", sh.width, sh.height, 255);

		// write the rows
        int n = sh.width*3;
		for (int y = 0; y<sh.height; y++) {
			char* ptr = (char *) img.PixelAddress(0, y, 0);
    		if ((int)fwrite(ptr, sizeof(uchar), n, stream) != n)  // ??? TODO: test this
                // ??? not sure this will work - RGB may be in wrong order
    			throw CError("WriteFilePGM(%s): file is too short", filename);
		}
	}
    */
    else if (nBands == 3 || nBands == 4) { // write PPM, ignoring alpha
		
		// write the header
		fprintf(stream, "P6\n%d %d\n%d\n", sh.width, sh.height, 255);

		// write the rows
        int n = sh.width*3;
		std::vector<uchar> rowBuf;
		rowBuf.resize(n);
		for (int y = 0; y<sh.height; y++) {
			uchar* ptr = (uchar *) img.PixelAddress(0, y, 0);
			int x = 0;
			while (x < n) {
				rowBuf[x++] = ptr[2];
				rowBuf[x++] = ptr[1];
				rowBuf[x++] = ptr[0];
				ptr += nBands;
			}

    		if ((int)fwrite(&rowBuf[0], sizeof(uchar), n, stream) != n)
    			throw CError("WriteFilePGM(%s): file is too short", filename);
		}
	}
	else
        throw CError("WriteFilePGM(%s): unhandled # of bands %d", filename, nBands);

    
    if (stream != stdout) {
	// close file
	if (fclose(stream))
	    throw CError("WriteFilePGM(%s): error closing file", filename);
    }
}

// 1-band PFM image, see http://netpbm.sourceforge.net/doc/pfm.html
// 3-band not yet supported
void WriteFilePFM(CFloatImage img, const char* filename, float scalefactor=1/255.0)
{
    // Write a PFM file
    CShape sh = img.Shape();
    int nBands = sh.nBands;
    if (nBands != 1)
	throw CError("WriteFilePFM(%s): can only write 1-band image as pfm for now", filename);
	
    // Open the file
    FILE *stream = fopen(filename, "wb");
    if (stream == 0)
        throw CError("WriteFilePFM: could not open %s", filename);

    // sign of scalefact indicates endianness, see pfms specs
    if (littleendian())
	scalefactor = -scalefactor;

    // write the header: 3 lines: Pf, dimensions, scale factor (negative val == little endian)
    fprintf(stream, "Pf\n%d %d\n%f\n", sh.width, sh.height, scalefactor);

    int n = sh.width;
    // write rows -- pfm stores rows in inverse order!
    for (int y = sh.height-1; y >= 0; y--) {
	float* ptr = (float *)img.PixelAddress(0, y, 0);
	if ((int)fwrite(ptr, sizeof(float), n, stream) != n)
	    throw CError("WriteFilePFM(%s): file is too short", filename);
    }
    
    // close file
    if (fclose(stream))
        throw CError("WriteFilePFM(%s): error closing file", filename);
}


//
// main dispatch functions
//

void ReadImage (CImage& img, const char* filename)
{
    if (filename == NULL)
	throw CError("ReadImage: empty filename");

    // Determine the file extension
    const char *dot = strrchr(filename, '.');
    if (dot == NULL)
	throw CError("ReadImage: extension required in filename '%s'", filename);

    if (strcmp(dot, ".TGA") == 0 || strcmp(dot, ".tga") == 0)
    {
        if ((&img.PixType()) == 0)
            img.ReAllocate(CShape(), typeid(uchar), sizeof(uchar), true);
        if (img.PixType() == typeid(uchar))
            ReadFileTGA(*(CByteImage *) &img, filename);
        else
           throw CError("ReadImage(%s): can only read CByteImage in TGA format", filename);
    }
    else if (strcmp(dot, ".pgm") == 0 || strcmp(dot, ".ppm") == 0 ||
             strcmp(dot, ".pmf") == 0)
    {
        if ((&img.PixType()) == 0)
        {
            if (strcmp(dot, ".pmf") == 0)
                img.ReAllocate(CShape(), typeid(float), sizeof(float), true);
            else
                img.ReAllocate(CShape(), typeid(uchar), sizeof(uchar), true);
        }
        if (img.PixType() == typeid(uchar) ||
            img.PixType() == typeid(float))
            ReadFilePGM(*(CByteImage *) &img, filename);
        else
           throw CError("ReadImage(%s): wrong image type for PGM/PPM/PMF", filename);
    }
    else if (strcmp(dot, ".pfm") == 0)
    {
        if ((&img.PixType()) == 0)
	    img.ReAllocate(CShape(), typeid(float), sizeof(float), true);
        if (img.PixType() == typeid(float))
            ReadFilePFM(*(CFloatImage *) &img, filename);
        else
           throw CError("ReadImage(%s): wrong image type for PFM", filename);
    }
#ifdef HAVE_PNG_LIB
    else if (strcmp(dot, ".PNG") == 0 || strcmp(dot, ".png") == 0)
    {
        if ((&img.PixType()) == 0)
            img.ReAllocate(CShape(), typeid(uchar), sizeof(uchar), true);
        if (img.PixType() == typeid(uchar))
            ReadFilePNG(*(CByteImage *) &img, filename);
        else
           throw CError("ReadImage(%s): can only read CByteImage in PNG format", filename);
    }
#endif
#ifdef HAVE_JPEG_READER
    else if (strcmp(dot, ".JPG") == 0 || strcmp(dot, ".jpg") == 0)
    {
        if ((&img.PixType()) == 0)
            img.ReAllocate(CShape(), typeid(uchar), sizeof(uchar), true);
        if (img.PixType() == typeid(uchar))
            ReadFileJPG(*(CByteImage *) &img, filename);
        else
           throw CError("ReadImage(%s): can only read CByteImage in JPG format", filename);
    }
#endif
    else
        throw CError("ReadImage(%s): file type not supported", filename);
}



// new 12/2/2013 DS: if filename == '-', write to stdout in .pgm / .ppm format
void WriteImage(CImage& img, const char* filename)
{
    if (filename == NULL)
	throw CError("WriteImage: empty filename");

    if (strcmp(filename, "-") == 0) { // write to stdout
        if (img.PixType() == typeid(uchar)) {
            WriteFilePGM(*(CByteImage *) &img, filename);
	    return;
	} else
	    throw CError("WriteImage: can only write Byte image to stdout");
    }

    // Determine the file extension
    const char *dot = strrchr(filename, '.');
    if (dot == NULL)
	throw CError("WriteImage: extension required in filename '%s'", filename);

    if (strcmp(dot, ".TGA") == 0 || strcmp(dot, ".tga") == 0)
    {
        if (img.PixType() == typeid(uchar))
            WriteFileTGA(*(CByteImage *) &img, filename);
        else
           throw CError("WriteImage(%s): can only write CByteImage in TGA format", filename);
    }
    else if (strcmp(dot, ".pgm") == 0 || strcmp(dot, ".ppm") == 0 ||
             strcmp(dot, ".pmf") == 0)
    {
        if (img.PixType() == typeid(uchar) ||
            img.PixType() == typeid(float))
            WriteFilePGM(*(CByteImage *) &img, filename);
        else
           throw CError("WriteImage(%s): wrong image type for PGM/PPM/PMF", filename);
    }
    else if (strcmp(dot, ".pfm") == 0)
    {
        if (img.PixType() == typeid(float))
            WriteFilePFM(*(CFloatImage *) &img, filename);
        else
           throw CError("WriteImage(%s): can only write CFloatImage in PFM format", filename);
    }
#ifdef HAVE_PNG_LIB
    else if (strcmp(dot, ".PNG") == 0 || strcmp(dot, ".png") == 0)
    {
        if (img.PixType() == typeid(uchar))
            WriteFilePNG(*(CByteImage *) &img, filename);
        else
           throw CError("WriteImage(%s): can only write CByteImage in PNG format", filename);
    }
#endif
    else
        throw CError("WriteImage(%s): file type not supported", filename);
}

// read an image and perhaps tell the user you're doing so
void ReadImageVerb(CImage& img, const char* filename, int verbose) {
	if (verbose)
		fprintf(stderr, "Reading image %s\n", filename);
	ReadImage(img, filename);
}

// write out an image and perhaps tell the user you're doing so
void WriteImageVerb(CImage& img, const char* filename, int verbose) {
	if (verbose)
		fprintf(stderr, "Writing image %s\n", filename);
	WriteImage(img, filename);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////Image.cpp

//
// struct CShape: shape of image (width x height x nbands)
//

bool CShape::operator==(const CShape& ref)
{
    // Are two shapes the same?
    return (width  == ref.width &&
            height == ref.height &&
            nBands == ref.nBands);
}

bool CShape::SameIgnoringNBands(const CShape& ref)
{
    // Are two shapes the same ignoring the number of bands?
    return (width  == ref.width &&
            height == ref.height);
}

bool CShape::operator!=(const CShape& ref)
{
    // Are two shapes not the same?
    return ! ((*this) == ref);
}


//
// class CImage : generic (weakly typed) image
//

void CImage::SetDefaults()
{
    // Set internal state to default values
    m_pTI = 0;              // pointer to type_info class
    m_bandSize = 0;         // size of each band in bytes
    m_pixSize = 0;          // stride between pixels in bytes
    m_rowSize = 0;          // stride between rows in bytes
    m_memStart = 0;         // start of addressable memory
    alphaChannel = 3;       // which channel contains alpha (for compositing)

    // Set default attribute values
    alphaChannel = 3;       // which channel contains alpha (for compositing)
    origin[0] = 0;          // x and y coordinate origin (for some operations)
    origin[1] = 0;          // x and y coordinate origin (for some operations)
    borderMode = eBorderReplicate;   // border behavior for neighborhood operations...
}

CImage::CImage()
{
    // Default constructor
    SetDefaults();
}

CImage::CImage(CShape s, const type_info& ti, int cS)
{
    SetDefaults();
    ReAllocate(s, ti, cS, 0, true, 0);
}

void CImage::ReAllocate(CShape s, const type_info& ti, int bandSize,
                        bool evenIfSameShape)
{
    if (! evenIfSameShape && s == m_shape && ti == *m_pTI && bandSize == m_bandSize)
        return;
    ReAllocate(s, ti, bandSize, 0, true, 0);
}

void CImage::ReAllocate(CShape s, const type_info& ti, int bandSize,
                        void *memory, bool deleteWhenDone, int rowSize)
{
    // Set up the type_id, shape, and size info
    m_shape     = s;                        // image shape (dimensions)
    m_pTI       = &ti;                      // pointer to type_info class
    m_bandSize  = bandSize;                 // size of each band in bytes
    m_pixSize   = m_bandSize * s.nBands;    // stride between pixels in bytes

    // Do the real allocation work
    m_rowSize   = (rowSize) ? rowSize :     // stride between rows in bytes
        (m_pixSize * s.width + 7) & -8;     // round up to 8 (quadwords)
    int nBytes  = m_rowSize * s.height;
    if (memory == 0 && nBytes > 0)          // allocate if necessary
    {
        memory = new double[(nBytes + 7)/ 8];
        if (memory == 0)
            throw CError("CImage::Reallocate: could not allocate %d bytes", nBytes);
    }
    m_memStart = (char *) memory;           // start of addressable memory
    m_memory.ReAllocate(nBytes, memory, deleteWhenDone);
}

void CImage::DeAllocate()
{
    // Release the memory & set to default values
    ReAllocate(CShape(), *(const type_info *) 0, 0, 0, false, 0);
    SetDefaults();
}


void CImage::SetSubImage(int x, int y, int width, int height)
{
    // Adjust the start of memory pointer
    m_memStart = (char *) PixelAddress(x, y, 0);

    // Compute area of intersection and adjust the shape and origin
    int x1 = __min(m_shape.width,  x+width);    // end column
    int y1 = __min(m_shape.height, y+height);   // end row
    x = __max(0, __min(x, m_shape.width));      // clip to original shape
    y = __max(0, __min(y, m_shape.height));     // clip to original shape
    m_shape.width  = x1 - x;                    // actual width
    m_shape.height = y1 - y;                    // actual height
}

void CImage::SetPixels(void *val_ptr)
{
    // Fill the image with a value
    uchar *vc = (uchar *) val_ptr;

    // Test if all the bytes are the same
    bool all_same = true;
    for (int b = 0; b < m_bandSize; b++)
        all_same = all_same && (vc[b] == vc[0]);

    // Iterate over the rows
    int nC = m_shape.width * m_shape.nBands;
    for (int y = 0; y < m_shape.height; y++)
    {
        uchar *rp = (uchar *) PixelAddress(0, y, 0);
        if (all_same)
            memset(rp, vc[0], nC * m_bandSize);
        else if (m_bandSize == sizeof(int))
        {
            int vi = *(int *) val_ptr;
            int *ip = (int *) rp;
            for (int c = 0; c < nC; c++)
                ip[c] = vi;
        }
        else
        {
            for (int c = 0; c < nC; c++, rp += m_bandSize)
                memcpy(rp, vc, m_bandSize);
        }
    }
}

//
// class CImageOf<T>: strongly typed image
//

template <> uchar CImageOf<uchar>::MinVal(void)     { return 0; }
template <> uchar CImageOf<uchar>::MaxVal(void)     { return 255; }
template <> int   CImageOf<int  >::MinVal(void)     { return 0x80000000; }
template <> int   CImageOf<int  >::MaxVal(void)     { return 0x7fffffff; }
template <> float CImageOf<float>::MinVal(void)     { return -FLT_MAX; }
template <> float CImageOf<float>::MaxVal(void)     { return FLT_MAX; }

////////////////////////////////////////////////////////////////////////////////////////////////////Convert.cpp

//
// Type conversion utilities
//

template <class T1, class T2>
extern void ScaleAndOffsetLine(T1* src, T2* dst, int n,
                        float scale, float offset,
                        T2 minVal, T2 maxVal)
{
    // This routine does NOT round values when converting from float to int
    const bool scaleOffset = (scale != 1.0f) || (offset != 0.0f);
    const bool clip = (minVal < maxVal);

    if (scaleOffset)
        for (int i = 0; i < n; i++)
        {
            float val = src[i] * scale + offset;
            if (clip)
                val = __min(__max(val, minVal), maxVal);
            dst[i] = (T2) val;
        }
    else if (clip)
        for (int i = 0; i < n; i++)
        {
            dst[i] = (T2) __min(__max(src[i], minVal), maxVal);
        }
    else if (typeid(T1) == typeid(T2))
        memcpy(dst, src, n*sizeof(T2));
    else
        for (int i = 0; i < n; i++)
        {
            dst[i] = (T2) src[i];
        }
}

template <class T1, class T2>
extern void ScaleAndOffset(CImageOf<T1>& src, CImageOf<T2>& dst, float scale, float offset)
{
    // Convert between images of same shape but diffent types,
    //  and optionally scale and/or offset the pixel values
    CShape sShape = src.Shape();
    CShape dShape = dst.Shape();

    // Make sure the shapes (ignoring bands) are compatible
    if (sShape != dShape)
        dst.ReAllocate(sShape);

    // Determine if clipping is required
    T2 minVal = dst.MinVal();
    T2 maxVal = dst.MaxVal();

    // if (minVal <= src.MinVal() && maxVal >= src.MaxVal())
    // changed DS 4/2003 - take into consideration scale and offset
    // removed DS 1/2004 - doesn't work for negative scales - safer to always clip
    //if (src.MinVal() * scale + offset >= minVal && 
    //    src.MaxVal() * scale + offset <= maxVal)
    //    minVal = maxVal = 0;

    // Process each row
    for (int y = 0; y < sShape.height; y++)
    {
        int n = sShape.width * sShape.nBands;
        ScaleAndOffsetLine(&src.Pixel(0, y, 0), &dst.Pixel(0, y, 0),
                           n, scale, offset, minVal, maxVal);
    }
}

template <class T>
extern CImageOf<T> ConvertToRGBA(CImageOf<T> src)
{
    // Check if already RGBA
    CShape sShape = src.Shape();
    if (sShape.nBands == 4 && src.alphaChannel == 3)
        return src;

    // Make sure the source is a gray image
    if (sShape.nBands != 1)
        throw CError("ConvertToRGBA: can only convert from 1-band (gray) image");

    // Allocate the new image
    CShape dShape(sShape.width, sShape.height, 4);
    CImageOf<T> dst(dShape);

    // Process each row
    int aC = dst.alphaChannel;
    for (int y = 0; y < sShape.height; y++)
    {
        T* srcP = &src.Pixel(0, y, 0);
        T* dstP = &dst.Pixel(0, y, 0);
        for (int x = 0; x < sShape.width; x++, srcP++)
            for (int b = 0; b < dShape.nBands; b++, dstP++)
                *dstP = (b == aC) ? 255 : *srcP;
    }
    return dst;
}

template <class T>
extern CImageOf<T> ConvertToGray(CImageOf<T> src)
{
    // Check if already gray
    CShape sShape = src.Shape();
    if (sShape.nBands == 1)
        return src;

    // Make sure the source is a color image
    if (sShape.nBands != 4 || src.alphaChannel != 3)
        throw CError("ConvertToGray: can only convert from 4-band (RGBA) image");

    // Allocate the new image
    CShape dShape(sShape.width, sShape.height, 1);
    CImageOf<T> dst(dShape);

    // Process each row
    T minVal = dst.MinVal();
    T maxVal = dst.MaxVal();
    for (int y = 0; y < sShape.height; y++)
    {
        T* srcP = &src.Pixel(0, y, 0);
        T* dstP = &dst.Pixel(0, y, 0);
        for (int x = 0; x < sShape.width; x++, srcP += 4, dstP++)
        {
            RGBA<T>& p = *(RGBA<T> *) srcP;
            // OLD FORMULA: float Y = (float)(0.212671 * p.R + 0.715160 * p.G + 0.072169 * p.B);
	    // Changed to commonly used formula 6/4/07 DS
            float Y = (float)(0.299 * p.R + 0.587 * p.G + 0.114 * p.B);
            *dstP = (T) __min(maxVal, __max(minVal, Y));
        }
    }
    return dst;
}

template <class T>
extern void BandSelect(CImageOf<T>& src, CImageOf<T>& dst, int sBand, int dBand)
{
    // Convert between images of same type but different # of bands
    CShape sShape = src.Shape();
    CShape dShape = dst.Shape();

    // Make sure the shapes (ignoring bands) are compatible
    if (! sShape.SameIgnoringNBands(dShape) || dShape.nBands == 0)
    {
        dShape.width  = sShape.width;
        dShape.height = sShape.height;
        dShape.nBands = (dShape.nBands) ? dShape.nBands : 1;
        dst.ReAllocate(dShape);
    }

    // Check the bands are valid
    int sB = sShape.nBands;
    int dB = dShape.nBands;
    if (sBand < 0 || sBand >= sB)
        throw CError("BandSelect: source band %d is invalid", sBand);
    if (dBand < 0 || dBand >= dB)
        throw CError("BandSelect: destination band %d is invalid", dBand);

    // Process each row
    for (int y = 0; y < sShape.height; y++)
    {
        T* srcP = &src.Pixel(0, y, 0);
        T* dstP = &dst.Pixel(0, y, 0);
        for (int x = 0; x < sShape.width; x++, srcP += sB, dstP += dB)
            dstP[dBand] = srcP[sBand];
    }
}

//
// Force instantiation for the types we care about (uchar, int, float)
//

// for some reason the following function doesn't work under gcc 4 with -O2:
/*
template <class T1>
void CopyPixelsInstantiate(CImageOf<T1>& s1)
{
    CByteImage  b2;
    CIntImage   i2;
    CFloatImage f2;
    CopyPixels(s1, b2);
    CopyPixels(s1, i2);
    CopyPixels(s1, f2);
}
*/
// ... so do it like this instead:
template void ScaleAndOffset(CByteImage&  src, CByteImage&  dst, float s, float o);
template void ScaleAndOffset(CByteImage&  src, CIntImage&   dst, float s, float o);
template void ScaleAndOffset(CByteImage&  src, CFloatImage& dst, float s, float o);
template void ScaleAndOffset(CIntImage&   src, CByteImage&  dst, float s, float o);
template void ScaleAndOffset(CIntImage&   src, CIntImage&   dst, float s, float o);
template void ScaleAndOffset(CIntImage&   src, CFloatImage& dst, float s, float o);
template void ScaleAndOffset(CFloatImage& src, CByteImage&  dst, float s, float o);
template void ScaleAndOffset(CFloatImage& src, CIntImage&   dst, float s, float o);
template void ScaleAndOffset(CFloatImage& src, CFloatImage& dst, float s, float o);

// also need (for Convolve) at least this:
template void ScaleAndOffsetLine(float* src, float* dst, int n, float scale, float offset, float minVal, float maxVal);

// same here:
template void BandSelect(CByteImage&  src, CByteImage&  dst, int sBand, int dBand);
template void BandSelect(CIntImage&   src, CIntImage&   dst, int sBand, int dBand);
template void BandSelect(CFloatImage& src, CFloatImage& dst, int sBand, int dBand);


template <class T>
int InstantiateConvert(CImageOf<T> src)
{
    //CopyPixelsInstantiate(src);
    CImageOf<T> r1 = ConvertToRGBA(src);
    CImageOf<T> r2 = ConvertToGray(src);
    //BandSelect(r1, r2, 0, 0);
    return (int)r1.Pixel(0, 0, 0);
}

void InstantiateAllConverts(void)
{
    InstantiateConvert(CByteImage());
    InstantiateConvert(CIntImage());
    InstantiateConvert(CFloatImage());
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////RefCntMem.cpp///////

CRefCntMem::CRefCntMem()
{
    // Default constructor
    m_ptr = 0;
}

CRefCntMem::~CRefCntMem()
{
    // Destructor
    DecrementCount();
    m_ptr = 0;      // not necessary, just for debugging
}

void CRefCntMem::DecrementCount()
{
    // Decrement the reference count and delete if done
    if (m_ptr)
    {
        m_ptr->m_refCnt -= 1;
        if (m_ptr->m_refCnt == 0)
        {
            if (m_ptr->m_deleteWhenDone)
            {
                if (m_ptr->m_delFn)
                    m_ptr->m_delFn(m_ptr->m_memory);
                else
                    delete (double *) m_ptr->m_memory;
            }
            delete m_ptr;
        }
    }
}

void CRefCntMem::IncrementCount()
{
    // Increment the reference count
    if (m_ptr)
    {
        m_ptr->m_refCnt += 1;
    }
}

CRefCntMem::CRefCntMem(const CRefCntMem& ref)
{
    // Copy constructor
    m_ptr = 0;
    (*this) = ref;      // use assignment operator
}

CRefCntMem& CRefCntMem::operator=(const CRefCntMem& ref)
{
    // Assignment
    DecrementCount();   // if m_ptr exists, no longer pointing to it
    m_ptr = ref.m_ptr;
    IncrementCount();
    return *this;
}

void CRefCntMem::ReAllocate(int nBytes, void *memory, bool deleteWhenDone,
                            void (*deleteFunction)(void *ptr))
{
    // Allocate/deallocate memory
    DecrementCount();
    if (memory)
    {
        m_ptr = new CRefCntMemPtr;
        m_ptr->m_nBytes = nBytes;
        m_ptr->m_memory = memory;
        m_ptr->m_deleteWhenDone = deleteWhenDone;
        m_ptr->m_refCnt = 1;
        m_ptr->m_delFn = deleteFunction;
    }
    else
        m_ptr = 0;  // don't bother storing pointer to null memory
}

int CRefCntMem::NBytes()
{
    // Number of stored bytes
    return (m_ptr) ? m_ptr->m_nBytes : 0;
}

bool CRefCntMem::InBounds(int index)
{
    // Check if index is in bounds
    return (m_ptr && 0 <= index && index < m_ptr->m_nBytes);
}

void* CRefCntMem::Memory()
{
    // Pointer to allocated memory
    return (m_ptr) ? m_ptr->m_memory : 0;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////end///////////

void evaldisp(CFloatImage disp, CFloatImage gtdisp, CByteImage mask, float badthresh, int maxdisp, int rounddisp)
{
	float INFINITY ;
	INFINITY = 1e10;
    CShape sh = gtdisp.Shape();
    CShape sh2 = disp.Shape();
    CShape msh = mask.Shape();
    int width = sh.width, height = sh.height;
    int width2 = sh2.width, height2 = sh2.height;
    int scale = width / width2;

    if ((!(scale == 1 || scale == 2 || scale == 4)) || (scale * width2 != width) || (scale * height2 != height)) 
	{
		printf("   disp size = %4d x %4d\n", width2, height2);
		printf("GT disp size = %4d x %4d\n", width,  height);
		throw CError("GT disp size must be exactly 1, 2, or 4 * disp size");
    }

    int usemask = (msh.width > 0 && msh.height > 0);
    if (usemask && (msh != sh))
	throw CError("mask image must have same size as GT\n");

    int n = 0;
    int bad = 0;
    int invalid = 0;
    float serr = 0;
    for (int y = 0; y < height; y++) 
	{
		for (int x = 0; x < width; x++) 
		{
				float gt = gtdisp.Pixel(x, y, 0);
				if (gt == INFINITY) // unknown
				continue;
				float d = scale * disp.Pixel(x / scale, y / scale, 0);
				int valid = (d != INFINITY);
				if (valid) 
				{
					float maxd = scale * maxdisp; // max disp range
					d = __max(0, __min(maxd, d)); // clip disps to max disp range
				}
				if (valid && rounddisp)
				d = round(d);
				float err = fabs(d - gt);
				if (usemask && mask.Pixel(x, y, 0) != 255) 
					{ // don't evaluate pixel
					} 
			else 
					{
						n++;
					if (valid) 
					{
						serr += err;
						if (err > badthresh) 
						{
							bad++;
						}
					} 
					else 
						{// invalid (i.e. hole in sparse disp map)
							invalid++;
						}
					}
		}
    }
    float badpercent =  100.0*bad/n;
    float invalidpercent =  100.0*invalid/n;
    float totalbadpercent =  100.0*(bad+invalid)/n;
    float avgErr = serr / (n - invalid); // CHANGED 10/14/2014 -- was: serr / n
    //printf("mask  bad%.1f  invalid  totbad   avgErr\n", badthresh);
    printf("%4.1f  %6.2f  %6.2f   %6.2f  %6.2f\n",   100.0*n/(width * height), 
	   badpercent, invalidpercent, totalbadpercent, avgErr);
}

int main(int argc, char *argv[])
{
    try 
	{
		int requiredargs = 3;
		int optionalargs = 3;
		if (argc >= requiredargs + 1 && argc <= requiredargs + optionalargs + 1) 
		{
			int argn = 1;
			char *dispname = argv[argn++];
			char *gtdispname = argv[argn++];
			float badthresh = atof(argv[argn++]);
			int maxdisp = 99999;
			if (argc > argn)
			maxdisp = atoi(argv[argn++]);
			int rounddisp = 0;
			if (argc > argn)
			rounddisp = atoi(argv[argn++]);
			char *maskname = NULL;
			if (argc > argn)
			maskname = argv[argn++];
      
			CFloatImage disp, gtdisp, gtdisp1;
			ReadImageVerb(disp, dispname, verbose);
			ReadImageVerb(gtdisp, gtdispname, verbose);
			CByteImage mask;
			if (maskname)
			ReadImageVerb(mask, maskname, verbose);

			evaldisp(disp, gtdisp, mask, badthresh, maxdisp, rounddisp);
		} 
		else
			if (argc == 2) 
			{
				float badthresh = atof(argv[1]);
				// show what the header looks like (can grep in scripts)
				printf("mask  bad%.1f  invalid  totalbad   avgErr\n", badthresh);
			}
		else
			throw CError(usage, argv[0]);
    }
		catch (CError &err) 
		{
			fprintf(stderr, err.message);
			fprintf(stderr, "\n");
			system("pause");
			return -1;
		}
		system("pause");
		return 0;
}
