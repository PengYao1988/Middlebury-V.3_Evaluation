// imageLib.h

// common includes

#ifndef CIMAGELIB
#define CIMAGELIB

#include "Error.h"
#include "Image.h"
#include "ImageIO.h"
#include "Convert.h"

int round(float f)
{ 
	if ((int)f+0.5>f) 
	return (int)f; 
	else 
	return (int)f + 1; 
}

#endif
